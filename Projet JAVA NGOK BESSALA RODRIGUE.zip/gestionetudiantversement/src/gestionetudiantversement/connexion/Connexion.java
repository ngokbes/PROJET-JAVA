/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionetudiantversement.connexion;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author PC
 */
public class Connexion {
   
    String url="jdbc:mysql://localhost:3306/versementetudiantbd";
    String utilisateur= "root"  ;
    String motDePasse="" ;
    Connection con;
    
 
    
     public void connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, utilisateur, motDePasse);
            JOptionPane.showMessageDialog(null,"connexion reussie");
        } catch (ClassNotFoundException e) {
            /* Gérer les éventuelles erreurs ici. */
        } catch (SQLException ex) {
            ex.printStackTrace();
        } 
    }
    
}


